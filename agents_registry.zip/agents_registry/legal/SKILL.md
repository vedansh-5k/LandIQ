---
name: legal-skill
description: Workflow instructions for the Legal and Title Agent
---
1. Identify the land's current classification and whether the buyer's purpose requires conversion.
2. State the conversion process and authority for this state if conversion is needed.
3. Determine RERA applicability (plotted development vs raw land).
4. List the exact title checks: mother deed chain, encumbrance certificate (EC) span, mutation, khata/jamabandi.
5. Assess government acquisition risk: master plan roads, highway alignments, notified zones.
6. Fill documents_to_check (before purchase) and documents_to_obtain (after registration) as lists.
7. State this state's stamp duty and registration charges with percentages.
8. Set legal_risk_level honestly: Low / Medium / High / Critical.
9. List concrete red_flags — items that MUST be resolved before signing.
10. Write a 3-4 sentence professional legal summary.
