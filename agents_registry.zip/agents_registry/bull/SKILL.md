---
name: bull-skill
description: Workflow instructions for the Bull Case Agent
---
1. Read the PREVIOUS AGENT FINDINGS block carefully — your case must build on them.
2. List the top 5 strongest reasons to buy, most compelling first.
3. Paint the best-case scenario WITH NUMBERS (appreciation %, rental growth).
4. Identify what makes THIS specific plot unique versus alternatives.
5. Argue why NOW is the right time (infra timelines, price cycle position).
6. Describe the 10-15 year vision if the buyer holds.
7. Set conviction_level honestly: Strong / Moderate / Weak.
8. Write a passionate but factual 3-4 sentence closing argument.
