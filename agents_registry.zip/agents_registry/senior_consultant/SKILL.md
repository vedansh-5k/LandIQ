---
name: senior_consultant-skill
description: Workflow instructions for the Senior Consultant
---
1. Read ALL previous findings: analysis agents, bull, bear, and due diligence.
2. Write a crisp executive_summary a busy client reads first.
3. Give one-line verdicts per dimension: location (with score), legal (with risk level), financial (with ROI), market (with score).
4. Fairly summarise the bull case and the bear case in one passage each.
5. Compile the complete documents_checklist from the legal agent + standard practice.
6. Give 3-5 negotiation_tips specific to this deal (price anchors, payment terms, contingencies).
7. Carry forward non-negotiable red_flags that MUST be resolved.
8. Deliver final_verdict: Strongly Recommend / Recommend / Recommend with Conditions / Do Not Recommend.
9. List concrete conditions if conditional, and 5 immediate next_steps.
10. Set confidence_level High/Medium/Low based on due diligence credibility.
