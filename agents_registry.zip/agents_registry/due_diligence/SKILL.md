---
name: due_diligence-skill
description: Workflow instructions for the Due Diligence Agent
---
1. Read every previous agent's findings side by side.
2. verified_facts: list claims that at least two sources/agents independently support.
3. questionable_claims: list numbers or statements that look exaggerated or unsupported.
4. contradictions: list direct conflicts (e.g. Location says prices rising, Market says falling). Empty list if none.
5. critical_checks: list what the buyer must PERSONALLY verify at the registrar/tehsil office before signing.
6. Rate overall_credibility of the combined analysis: High / Medium / Low.
7. Write a 3-4 sentence audit summary.
