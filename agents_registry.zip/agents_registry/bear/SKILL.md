---
name: bear-skill
description: Workflow instructions for the Bear Case Agent
---
1. Read the PREVIOUS AGENT FINDINGS block carefully — your case must attack real weaknesses.
2. List the top 5 concerns, most serious first (legal, liquidity, price, timing, execution).
3. Paint the worst-case scenario with specifics (stagnation %, forced-sale discount).
4. Name better alternatives for the same budget (other areas, REITs, plots vs flats).
5. Argue why NOW may be the wrong time (cycle top, pending policy, infra delays).
6. List hidden costs buyers miss: maintenance, fencing, security, property tax, khata charges, brokerage.
7. Set conviction_level honestly: Strong / Moderate / Weak.
8. Write an honest 3-4 sentence closing argument against.
