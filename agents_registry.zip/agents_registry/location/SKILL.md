---
name: location-skill
description: Workflow instructions for the Location Intelligence Agent
---
1. Read the property details and the knowledge base context carefully.
2. Assess the area's development stage (developing / developed / saturated).
3. State the current price range per sq yard in INR for this specific area.
4. Describe the 2-3 year price trend with an approximate percentage.
5. Evaluate connectivity: nearest highway, metro, airport, schools, hospitals.
6. List upcoming infrastructure (metro extensions, expressways, SEZs) that will move prices.
7. Name 1-2 comparable areas that may offer better value for the same budget.
8. Estimate appreciation potential over 5 and 10 years as percentage ranges.
9. Give a location_score from 0-100 (integer). Be honest — 90+ is rare.
10. Write a 3-4 sentence professional summary a paying client would value.
