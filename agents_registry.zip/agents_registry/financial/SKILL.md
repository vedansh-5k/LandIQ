---
name: financial-skill
description: Workflow instructions for the Financial ROI Agent
---
1. Compute land_cost from area price benchmarks x plot size (or use the stated budget).
2. Compute registration_stamp_duty using this state's rates (typically 5-8% combined).
3. Estimate construction_cost only if the purpose involves construction, else 0.
4. total_investment = land + stamp duty + construction (+ ~1-2% misc).
5. Estimate monthly_rental_income realistically for this area and land type (0 if raw land held vacant).
6. annual_rental_yield = (monthly rent x 12) / total_investment x 100.
7. breakeven_years = total_investment / (monthly rent x 12); use 0 if no rental.
8. roi_5_year and roi_10_year = appreciation + cumulative rent, as total percentage.
9. If a loan is taken, compute an approximate EMI at the given rate, else say "No loan".
10. Set financial_viability: Excellent / Good / Average / Poor, and summarise with the key numbers.
