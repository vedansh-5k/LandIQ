---
name: market-skill
description: Workflow instructions for the Market Intelligence Agent
---
1. Rate current demand High/Medium/Low and justify with drivers (jobs, infra, migration).
2. Describe the typical buyer profile in this area (end-users, investors, NRIs, developers).
3. Name the kind of developer activity present (national developers, local builders, none).
4. Summarise recent transaction levels and achieved prices from the knowledge context.
5. Call the market: buyer's market or seller's market right now, and why.
6. Assess exit strategy: how fast could this plot resell, to whom, at what discount/premium.
7. List market-specific risk factors (oversupply, litigation-heavy belt, speculative pricing).
8. Give market_score 0-100 (integer), honest and calibrated.
9. Write a 3-4 sentence professional market summary.
